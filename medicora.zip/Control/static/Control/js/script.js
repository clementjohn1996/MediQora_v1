console.log("JavaScript file loaded successfully!");
